<%-- 
    Document   : a
    Created on : 08-01-2026, 16:57:40
    Author     : trant
--%>

<%@page import="models.UserDTO"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <%
            UserDTO user = (UserDTO)session.getAttribute("user");
       
            if (user!=null){
        %>
            Welcome <%=user.getFullName()%>,<br/>
            <a href="MainController?action=logout">Logout</a> <br/>
            Bang dieu khien <br/>
            Tinh nang 1 <br/>
            Tinh nang 2 <br/>
            Tinh nang 3 <br/>
        <%
            } else {
                response.sendRedirect("login.jsp");
            }
        %>
    </body>

</html>
